from models.mysql.connector import db_config
from models.index import database_info,mysql_user_table,user_profile,show_tables,show_databases,RandPassword

#* Route 
Route = {
    "index" : {
        "pageViews": "/",
        "titleViews": "MySQLDev - Home",
        "nameViews": "index.html",
        "ProfileUser": user_profile.get_user_profile(),
        "ServerType": database_info.get_server_type(),
        "ServerCon": database_info.get_server_connection_id(),
        "user": db_config['user'],
        "host": db_config['host'],
        "dbname": db_config['database'],
        "versionDb": database_info.get_db_version(),
        "Mysql_User": mysql_user_table.get_users(),
        "Mysql_Header": mysql_user_table.get_user_table_header(),
        "ShowTables" : show_tables.ShowTables(),
        "ShowDB" : show_databases.ShowDatabases(),
        "RandPw" : RandPassword.RandomPw(),
    },
    "ChangeDb" :{
        "pageViews" : "/ChangeDatabase",
    },
    "DeleteMysqlUser" :{
        "pageViews" : "/DeleteMysqlUser",
    },
    "TableViews" : {
        "pageViews" : "/Table/",
        "titleViews": "MySQLDev - View Tables",
        "nameViews": "ViewTables.html",
    },
    "EditColumn" :{
        "pageViews" : "/Table/EditColumn",
        "titleViews" : "MySQLDev - Edit Column",
        "nameViews" : "EditColumn.html"
    }
}